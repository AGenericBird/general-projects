# This function goes through and looks for the filtered category list and looks at the URL to see if the user colour is there

def colour_search(input_category_list, input_colour):
    
    item_output = []
    
    for row in input_category_list:
        if input_colour in row[2]:
            item_output.append(row)
    
    return item_output