# Student # W0520049
# Michael Laprise

#This will be the beginning of my final project. 
#Instances of the word Caf√© in csv file were replaced with Cafe, also removed header
import csv
import search_category
import search_colour
import price_calculations

# main function that calls upon other functions and does calcs and such within
def main():
    
    shopping_cart = []
    while True:
        converted_to_list = []
        # Aquire the ability to read csv file
        # prompt user to input what type of item they want. Use category from Col 3 of CSV file for displayed options
        with open('ikea2.csv', 'r', newline='') as csvfile:
                entryreader = csv.reader(csvfile, delimiter=",")
                for entry in entryreader:
                    converted_to_list.append(entry)
                    
        # call upon function to search through csv file for user input
        # function goes through the csv, stores relevant user choice into a list, storing by the unique ID of each item.
        category_list = search_category.category_search(converted_to_list)

        
        while True:
            print("\nThese are all the categories available in our store:")
            for category in category_list:
                print(category, end=", ")
            user_category_choice = input("\nPlease let us know which category you want to search: ").lower()
            if user_category_choice in str(category_list).lower():
                # This filters out the original list and creates a filtered list with only Item ID, URL, and Category
                filtered_category_list = search_category.category_list_filter(user_category_choice, converted_to_list)
                print("Great choice, let's now proceed to colour\n")
                break
        
        # print(filtered_category_list)
        
        # prompts user for their colour of choice
        # display common options found within the list
        #As I lack the knowledge to properly go through and get all the colours from the urls in the csv file, nor did I want to import a csv list of common colours
        # Because of this, some of the items do not appear in the program as they do not have a colour associated with their url, this is my own oversight. 
        manual_colour_list = ["Black", "Silver", "Brown", "Grey", "White", "Beige", "Turquoise", "Red", "Pink", "Green", "Orange", "Bronze", "Yellow", "Blue" ]
        while True:
            print(f"These are the typical colours seen in our store:\n")
            for colour in manual_colour_list:
                print(colour, end=", ")
            user_colour_choice = input("\nPlease enter which colour you want to see for your selected item (Keep in mind it might not have that colour available): ").lower()
            if user_colour_choice in str(manual_colour_list).lower():
            # Function gets called that culls through existing list 
            # The existing list from previous function gets used for it's unique IDs.
            # This function goes through the unique URL links for the colour that user inputted. Spits out all that match
            # if colour is not found, prompt user if they want to search again. If they don't quit/end program
                filtered_category_colour_list = search_colour.colour_search(filtered_category_list, user_colour_choice)
                if not filtered_category_colour_list:
                    print("We found no match, please choose another colour:\n")
                elif len(filtered_category_colour_list) == 1:
                    print("We found a match, proceeding with the program\n")
                    shopping_cart.append(filtered_category_colour_list)
                    break
                elif len(filtered_category_colour_list) > 1:
                    print("We found multiple matches, please choose which you want to add: \n")
                    line_num = 1
                    for choice in filtered_category_colour_list:
                        print(line_num, " ", choice[2], end=",")
                        line_num += 1
                    while True:
                        item_choice = input("Please select which number you want (1, 2... 9): ")
                        try:
                            if int(item_choice) > len(filtered_category_colour_list) or int(item_choice) <= 0:
                                print("That was not a numbered choice, try again.\n")
                            else:
                                shopping_cart.append(filtered_category_colour_list[int(item_choice) - 1])
                                break
                            # print(shopping_cart) 
                        except ValueError:
                            print("That was not a numbered choice, try again.\n")
                    break            
            else:
                print("Sorry, I did not quite get that, please type again.\n")

        # search_colour.colour_search(user_category_choice, user_colour_choice)
            
        # If colour is found and user wants to add to a cart, the item Unique ID get's added to a list. 
        
        exit_and_pay_input = input(f"\nType 'Shopping' if you want to add another item to your cart, if else this will proceed to checkout: ").lower()
        if not exit_and_pay_input == "shopping":
            print("Exiting to checkout")
            break
        else:
            print("Starting over to add another item")
    
    # final function is to cull through and calculate total price (with 15% tax) on all items in the cart
        # Takes the Unique IDs from Cart List, takes the price from col 4
        # makes sure the prices are proper floats
        # calculates full price with tax included
    
    print("\n------------------------------------------------------------------------------------------------------------------")
    print(price_calculations.price_calculator(shopping_cart)) 
    print("------------------------------------------------------------------------------------------------------------------\n")
    print("\n Ending program, enjoy your day!")
    
            
    # End program
    
if __name__ == "__main__":
    main()  