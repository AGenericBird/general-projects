#This is for a function that searches the csv file for the specified furniture type the user requested.

def category_search(list_input):
    
    list_of_categories = []
    
    for row in list_input:
        for item in row:
            if row[2] == item and item not in list_of_categories:
                list_of_categories.append(item)
              
    return list_of_categories

# goes through and creates a now list for all the items from the category that the user inputed
def category_list_filter(filered_input, list_input):
    
    filtered_category_list = []
    for row in list_input:
        # print(row)
        if filered_input in str(row).lower():
            filtered_category_list.append([row[0], row[3], row[6]])
    
    return filtered_category_list
