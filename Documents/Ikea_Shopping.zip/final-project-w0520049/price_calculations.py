# function calculates all the prices related to the items in the carts.

def price_calculator(shopping_cart):
    
    price_before_tax = 0
    tax_percent = 0.15
    individual_price_tracker = []
    
    if len(shopping_cart) > 1:
        for items in shopping_cart:
            price_before_tax += float(items[1])
            individual_price_tracker.append(float(items[1]))
        average_price = sum((individual_price_tracker))/len(individual_price_tracker)
                         
    elif len(shopping_cart) == 1:
        # print(shopping_cart)
        price_before_tax = float(shopping_cart[0][1])
        average_price = price_before_tax
        
    # print(price_before_tax)
        
    total_price = price_before_tax + (price_before_tax * tax_percent)
    
    total_price_text = (f"The total price of purchase is ${total_price:.2f}, with the average price of an item being ${average_price:.2f}.")
    
    return total_price_text